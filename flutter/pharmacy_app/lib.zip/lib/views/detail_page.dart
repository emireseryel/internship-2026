import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:pharmacy_app/models/pharmacy_model.dart';

class DetailPage extends StatelessWidget {
  Pharmacy pharmacy;

  DetailPage({super.key, required this.pharmacy});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Padding(
              padding: EdgeInsetsGeometry.only(top: 10, right: 15),
              child: SizedBox(
                width: 50,
                height: 50,
                child: Image.asset(
                  'assets/images/pharmacy-logo.png',
                  fit: BoxFit.contain,
                ),
              ),
            ),
            Text('detail_page'.tr()),
          ],
        ),
      ),

      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              "${pharmacy.name}",
              style: TextStyle(fontSize: 50, fontWeight: FontWeight.bold),
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              'detail_district'.tr()+"${pharmacy.address}",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.normal,),
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              'detail_phone'.tr()+"${pharmacy.phone}",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.normal,),
            ),
          ),
        ],
      ),
    );
  }
}
