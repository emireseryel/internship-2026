import 'package:flutter/material.dart';
import 'package:pharmacy_app/models/pharmacy_model.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:pharmacy_app/views/detail_page.dart';

class ResultPage extends StatelessWidget {
  // 1. Dışarıdan gelecek listeyi tutacak değişkeni tanımlıyoruz
  final List<Pharmacy> pharmacies;

  // 2. Constructor (Yapıcı metot) ile bu listenin verilmesini zorunlu kılıyoruz
  const ResultPage({super.key, required this.pharmacies});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Padding(
              padding: EdgeInsetsGeometry.only(top: 10, right: 15),
              child: SizedBox(
                width: 50,
                height: 50,
                child: Image.asset(
                  'assets/images/pharmacy-logo.png',
                  fit: BoxFit.contain,
                ),
              ),
            ),
            Text('result_page'.tr()),
          ],
        ),
      ),
      body: pharmacies.isEmpty
          ? Center(child: Text('warning_not_found'.tr()))
          : ListView.builder(
              itemCount: pharmacies.length,
              itemBuilder: (context, index) {
                final pharmacy = pharmacies[index];
                return ListTile(
                  leading: Image.asset('assets/images/pharmacy-icon.png'),
                  title: Text(pharmacy.name),
                  trailing: ElevatedButton
                  (onPressed: (){
                    Navigator.push(
                      context, 
                      MaterialPageRoute(
                        builder: (context) => DetailPage(pharmacy: pharmacy),
                        ),
                    );
                  }, 
                  child: Text('see_details'.tr())),
                );
              },
            ),
    );
  }
}